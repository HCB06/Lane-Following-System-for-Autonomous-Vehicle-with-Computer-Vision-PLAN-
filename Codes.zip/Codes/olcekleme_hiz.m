function [scaled_vector] = olcekleme_hiz(vector)

%{
 abs_vector = abs(vector);
    max_abs = max(abs_vector(:));
    scaled_vector = vector / max_abs;

%}
		min_value = min(vector(:));
		max_value = max(vector(:));
		
		scaled_vector = 0 + (vector - min_value) * (1 - 0) / (max_value - min_value); % Ölçeklendirme
		
