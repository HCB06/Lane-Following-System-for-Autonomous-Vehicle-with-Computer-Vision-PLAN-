function custom_run(input_layer,weight1,weight2,weight3,i,output)

																							%% İNPUT KATMANI %%
		
		inp = find(input_layer < 150);
		
			weight1(:,inp(:)) = 0;
		
		hidden_layer1 = (weight1 * input_layer);
																							%% GİZLİ KATMAN 1 %%
		



	
			
		hidden_layer2 = (weight2 * hidden_layer1);
		
																							%% ÇIKTI KATMANI %%

		
		output_layer = (weight3 * hidden_layer2);
		

		
		[output_layer] = olcekleme(output_layer);
		
		
		output_layer = output_layer * (output * 10);
		
		i = find(max(output_layer));
		
		output_layer(i) = output_layer(i) * 1.1;
		
		i = 0;
		
		for i = 2:3
				
		
		%output_layer
		
			dosya_adi = sprintf('output%d.txt', i);
			fid = fopen(fullfile(pwd, dosya_adi), 'w');

			if fid == -1
				disp('Dosya açma hatası');
			
			else

			fprintf(fid, '%f', output_layer(i-1));

			if fclose(fid) == -1
				disp('Dosyayı kapatma hatası');
			end
		end

		end