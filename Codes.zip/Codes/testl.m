function testl(weight1,weight2,weight3,w1,w2,w3,i,output)

while true
i++;
try
photo = sprintf('Assets/CapturedPhotos/photo.jpg');
img = imread(photo);
img = single(img);
img = rgb2gray(img);
catch
pause(0.00001)
testl(weight1,weight2,weight3,w1,w2,w3,i,output)
end
input_layer = img(:);
input_layer = single(input_layer);

hidden_layer1 = ones(320) / 2;
hidden_layer2 = ones(150) / 2;
output_layer = ones(2) / 2;



%save('hidden_layer1.mat', 'hidden_layer1');
%save('hidden_layer2.mat', 'hidden_layer2');
%save('output_layer.mat', 'output_layer');

custom_run(input_layer,weight1,weight2,weight3,i,output);
[output] = custom_run_hiz(input_layer,w1,w2,w3,output);


end