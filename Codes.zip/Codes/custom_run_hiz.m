function [output] = custom_run_hiz(input_layer,w1,w2,w3,output)

		weight1 = w1;
		weight2 = w2;
		weight3 = w3;

																							%% İNPUT KATMANI %%
		
		inp = find(input_layer < 150);
		
			weight1(:,inp(:)) = 0;
		
		hidden_layer1 = (weight1 * input_layer);
																							%% GİZLİ KATMAN 1 %%
		



	
			
		hidden_layer2 = (weight2 * hidden_layer1);
		
																							%% ÇIKTI KATMANI %%

		
		output_layer = (weight3 * hidden_layer2);
		

		
		[output_layer] = olcekleme(output_layer);
		

		
		
		
		if output_layer(2) > 0.58
		
		output_layer(2) = output_layer(2) / 70;
		output -= (output_layer(2));
		%output = abs(output);
		else
		
		if output < 1
		output_layer(1) = output_layer(1) / 100;
		output += output_layer(1);
		end
		end
		
		
		
		disp('Toplam Hız:');
		disp(output);
		
		pause(0.1)
		
		dosya_adi = sprintf('output1.txt');
			fid = fopen(fullfile(pwd, dosya_adi), 'w');

			if fid == -1
				disp('Dosya açma hatası');
			
			else

			fprintf(fid, '%f', output);

			if fclose(fid) == -1
				disp('Dosyayı kapatma hatası');
			end
		end

		