function start()


		dosyaAdi = sprintf('hiz_bilgiler/w1.mat');
    load(dosyaAdi);
    
		dosyaAdi2 = sprintf('hiz_bilgiler/w2.mat');
    load(dosyaAdi2);
	
	dosyaAdi3 = sprintf('hiz_bilgiler/w3.mat');
    load(dosyaAdi3);
	
	w1 = weight1;
	w2 = weight2;
	w3 = weight3;
	
	
	dosyaAdi = sprintf('bilgiler/weight1.mat');
    load(dosyaAdi);
    
		dosyaAdi2 = sprintf('bilgiler/weight2.mat');
    load(dosyaAdi2);
	
	dosyaAdi3 = sprintf('bilgiler/weight3.mat');
    load(dosyaAdi3);
	
	whos
	
	output = 0;
	
	testl(weight1,weight2,weight3,w1,w2,w3,0,output);